package com.example.Program_Task_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgramTaskManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgramTaskManagementApplication.class, args);
	}

}

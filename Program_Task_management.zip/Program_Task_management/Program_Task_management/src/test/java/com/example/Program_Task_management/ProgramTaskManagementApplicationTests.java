package com.example.Program_Task_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgramTaskManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}

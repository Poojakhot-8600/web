package com.book;

import java.util.ArrayList;
import java.util.List;

public class BookData {
    private static List<Book> books = new ArrayList<>();

    static {
        
        books.add(new Book("Java Programming", "John Doe", "Programming", 29.99, true));
        books.add(new Book("Databases 101", "Jane Smith", "Database", 19.99, false));
        books.add(new Book("Fictional Worlds", "Alice Johnson", "Fiction", 24.99, true));
    }

    public static List<Book> getBooks() {
        return books;
    }

    public static void addBook(Book book) {
        books.add(book);
    }
}

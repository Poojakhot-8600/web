import java.util.*;

public class BookData {
    public static List<Book> getBooks() {
        List<Book> books = new ArrayList<>();
        books.add(new Book("Java Programming", "James Gosling", "Programming", 500, true));
        books.add(new Book("Effective Java", "Joshua Bloch", "Programming", 600, true));
        books.add(new Book("Harry Potter", "J.K. Rowling", "Fiction", 300, false));
        books.add(new Book("The Alchemist", "Paulo Coelho", "Fiction", 400, true));
        books.add(new Book("Database Systems", "C.J. Date", "Database", 700, true));
        return books;
    }
}

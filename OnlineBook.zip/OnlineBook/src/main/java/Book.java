public class Book {
    private String title;
    private String author;
    private String genre;
    private double price;
    private boolean inStock;

    public Book(String title, String author, String genre, double price, boolean inStock) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.price = price;
        this.inStock = inStock;
    }

    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getGenre() { return genre; }
    public double getPrice() { return price; }
    public boolean isInStock() { return inStock; }
}
